def reverse_string(text):
    text=text.split()
    text=list(reversed(text))
    return ' '.join(text)



def capitalize_string(text):
	return text.capitalize()
	 
