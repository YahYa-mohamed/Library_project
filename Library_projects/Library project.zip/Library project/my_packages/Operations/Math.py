def get_average(list_of_numbers):
    return sum(list_of_numbers)/len(list_of_numbers)
	